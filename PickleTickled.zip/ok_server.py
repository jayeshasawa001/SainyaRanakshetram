import os
import pickle
import json

def isJson(chk):
	try:
		chk = "\"" + str(chk) + "\""
		json.loads(chk)
	except ValueError as e:
		return False
	return True

def reverse_fun():
      with open("users.json","rb") as f:
          data = f.read()
      if b'R' in data:
      	return "No RCEs please."
      d = pickle.loads(data)
      d = str(d)
      if not isJson(d):
      	return "JSON Object not found"
      if d.find("'username'") == -1 or d.find("'password'") == -1:
      	return "Un-Original JSON"
      return d

if __name__ == '__main__':
      print(reverse_fun())